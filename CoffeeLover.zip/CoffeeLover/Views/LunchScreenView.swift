//
//  LunchScreenView.swift
//  CoffeeLover
//
//  Created by Norayr on 09.07.23.
//

import UIKit
import Lottie

class LunchScreenView {
    
   
    
    
    
    
    
}
