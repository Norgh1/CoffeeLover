//
//  MainTableViewCell.swift
//  CoffeeLover
//
//  Created by Norayr on 12.07.23.
//

import UIKit

class MainTableViewCell: UITableViewCell {

    
    @IBOutlet weak var nameCoffeLabel: UILabel!
    @IBOutlet weak var priceCoffeLabel: UILabel!
    @IBOutlet weak var imageCoffe: UIImageView!
    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        imageCoffe.layer.cornerRadius = contentView.frame.height / 4
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }

}



