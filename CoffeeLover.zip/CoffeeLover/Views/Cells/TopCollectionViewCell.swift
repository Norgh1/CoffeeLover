//
//  TopCollectionViewCell.swift
//  CoffeeLover
//
//  Created by Norayr on 10.07.23.
//

import UIKit

class TopCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var coffeLabel: UILabel!
    @IBOutlet weak var coffeeImage: UIImageView!
    
    override class func awakeFromNib() {
        super.awakeFromNib()
    }
    
    init(coffeLabel: UILabel!, coffeeImage: UIImageView!) {
        super.init(frame: CGRect())
        self.coffeLabel = coffeLabel
        self.coffeeImage = coffeeImage
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
    }
    
}
