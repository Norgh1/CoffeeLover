//
//  FetchAllCoffe.swift
//  CoffeeLover
//
//  Created by Norayr on 09.07.23.
//

import Foundation

protocol fetchAllCoffee {
    
    //MARK: TODO-
    
    func fetchCoffee()
    
}
