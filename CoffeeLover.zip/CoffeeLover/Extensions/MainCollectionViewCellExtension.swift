//
//  MainCollectionViewCellExtension.swift
//  CoffeeLover
//
//  Created by Norayr on 12.07.23.
//

import Foundation
import UIKit


extension WelcomeViewController: UITableViewDataSource, UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        WelcomeViewController.shared.listOfCoffeName.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "coffeecell", for: indexPath) as! MainTableViewCell
        cell.nameCoffeLabel.text = WelcomeViewController.shared.listOfCoffeName[indexPath.row]
        cell.priceCoffeLabel.text = WelcomeViewController.shared.lsitofCoffePrice[indexPath.row]
        cell.imageCoffe.image = UIImage(named: WelcomeViewController.shared.listofPicture[indexPath.item])
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let storyboard = storyboard?.instantiateViewController(identifier: "selectedvc") as! SelectedCoffeeViewController
        storyboard.modalPresentationStyle = .overFullScreen
        storyboard.navigationItem.rightBarButtonItem?.title = "defff"
        present(storyboard, animated: true)
    }

    func configureDataSourseDelegate() {
        self.mainTableView.rowHeight = 100
        self.mainTableView.delegate = self
        self.mainTableView.dataSource = self
    }
}
