//
//  SelectedCoffeeViewControllerExtension.swift
//  CoffeeLover
//
//  Created by Norayr on 13.07.23.
//

import Foundation
import UIKit

extension SelectedCoffeeViewController {

}
