//
//  TopCollectionViewCellExtension.swift
//  CoffeeLover
//
//  Created by Norayr on 10.07.23.
//

import Foundation
import UIKit


extension WelcomeViewController: UICollectionViewDelegate, UICollectionViewDataSource {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        listOfCoffeName.count
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "topcell", for: indexPath) as! TopCollectionViewCell
        cell.coffeLabel.text = listOfCoffeName[indexPath.row]
        cell.coffeeImage.image = UIImage(named: WelcomeViewController.shared.listofPicture[indexPath.row])
        return cell
    }
    //MARK: collection view delegate - datasource
    func configureCollectionView() {
        self.topCollectionView.delegate = self
        self.topCollectionView.dataSource = self
    }
    
}
