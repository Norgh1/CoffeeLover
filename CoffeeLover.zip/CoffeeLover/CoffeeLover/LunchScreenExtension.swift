//
//  LunchScreenExtension.swift
//  CoffeeLover
//
//  Created by Norayr on 13.07.23.
//

import UIKit
import Foundation
import Lottie


final class LunchScreen: UIViewController {
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    
}
