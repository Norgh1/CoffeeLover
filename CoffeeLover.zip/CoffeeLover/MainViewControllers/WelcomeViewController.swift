//
//  ViewController.swift
//  CoffeeLover
//
//  Created by Norayr on 09.07.23.
//



import UIKit

class WelcomeViewController: UIViewController {
    
    static let shared = WelcomeViewController()
    
    var lsitofCoffePrice = ["10 USD","20 USD","30 USD","15 USD","17 USD","23 USD","10 USD","10 USD","10 USD"]
    var listOfCoffeName = ["MacCoffe","Machato","Capuchino","Nescaffe","Coffe","MacCoffe","Machato","Capuchino","Nescaffe"]
    var listofPicture = ["coffeeOther", "images", "Mochito", "nescaffe", "otherCoffee","coffeeOther", "coffeeOther","nescaffe","Coffe","Mochito"]
    
    @IBOutlet weak var topCollectionView: UICollectionView!
    @IBOutlet weak var mainTableView: UITableView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        configureDataSourseDelegate()
        configureCollectionView()
        reloadData()
    }

    private func reloadData(){
        self.topCollectionView.reloadData()
        self.mainTableView.reloadData()
    }

}
