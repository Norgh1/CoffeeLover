//
//  SecectedCoffeeViewController.swift
//  CoffeeLover
//
//  Created by Norayr on 13.07.23.
//

import UIKit
import Lottie

class SelectedCoffeeViewController: UIViewController {

    @IBOutlet weak var animationView: LottieAnimationView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        animationView = .init(name: "coffee")
        animationView.frame = view.bounds
        animationView.play()
        animationView.loopMode = .repeat(1)
        view.addSubview(animationView)
    }
    
    @IBAction func dissmissButton(_ sender: Any) {
        self.dismiss(animated: true)
    }
}
